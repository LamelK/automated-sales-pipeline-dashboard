import os
import csv
import pymysql
import boto3
import time
from io import StringIO

# Load env variables from Lambda environment variables
rds_host = os.environ['RDS_HOST']
rds_user = os.environ['RDS_USER']
rds_password = os.environ['RDS_PASSWORD']
rds_db = os.environ['RDS_DB']
bucket_name = os.environ['BUCKET_NAME']

s3 = boto3.client('s3')

def get_csv_from_s3(file_key):
    print(f"📥 Reading: {file_key}")
    obj = s3.get_object(Bucket=bucket_name, Key=file_key)
    return list(csv.DictReader(StringIO(obj['Body'].read().decode('utf-8'))))

def get_product_name_by_id(product_id, products_csv):
    for row in products_csv:
        if int(row['product_id']) == int(product_id):
            return row['product_name']
    return None

def get_store_location_by_id(store_id, stores_csv):
    for row in stores_csv:
        if int(row['store_id']) == int(store_id):
            return row['store_location']
    return None

def get_product_id_map(cursor):
    cursor.execute("SELECT product_name, product_id FROM products")
    mapping = {name: pid for name, pid in cursor.fetchall()}
    print(f"🔄 Loaded {len(mapping)} product mappings from RDS.")
    return mapping

def get_store_id_map(cursor):
    cursor.execute("SELECT store_location, store_id FROM stores")
    mapping = {loc: sid for loc, sid in cursor.fetchall()}
    print(f"🔄 Loaded {len(mapping)} store mappings from RDS.")
    return mapping

def lambda_handler(event, context):
    try:
        print("🔌 Connecting to RDS...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            port=3306
        )
        cursor = conn.cursor()

        print("🧹 Deleting existing customers and sales...")
        cursor.execute("DELETE FROM sales")
        cursor.execute("DELETE FROM customers")
        conn.commit()

        print("📥 Loading all 4 CSVs from S3...")
        customers_csv = get_csv_from_s3('transformed_data/customers.csv')
        sales_csv = get_csv_from_s3('transformed_data/sales.csv')
        products_csv = get_csv_from_s3('transformed_data/products.csv')
        stores_csv = get_csv_from_s3('transformed_data/stores.csv')

        print("📦 Preparing customers...")
        customer_values = [
            (int(row['customer_id']), row['customer_name']) for row in customers_csv
        ]

        print("📦 Inserting customers...")
        start = time.time()
        cursor.executemany(
            "INSERT INTO customers (customer_id, customer_name) VALUES (%s, %s)",
            customer_values
        )
        conn.commit()
        print(f"✅ Inserted {len(customer_values)} customers in {round(time.time() - start, 2)}s.")

        print("🔎 Mapping foreign keys...")
        product_id_map = get_product_id_map(cursor)
        store_id_map = get_store_id_map(cursor)

        print("📦 Preparing sales...")
        sales_values = []
        skipped = 0

        for row in sales_csv:
            product_name = get_product_name_by_id(row['product_id'], products_csv)
            store_location = get_store_location_by_id(row['store_id'], stores_csv)

            real_product_id = product_id_map.get(product_name)
            real_store_id = store_id_map.get(store_location)

            if real_product_id is None or real_store_id is None:
                print(f"⚠️ Skipped: transaction_id={row['transaction_id']}, "
                      f"product={product_name}, store={store_location}")
                skipped += 1
                continue

            sales_values.append((
                int(row['transaction_id']),
                row['day_of_week'],
                float(row['price']),
                float(row['quantity_sold']),
                float(row['total_sale']),
                int(row['customer_id']),
                real_product_id,
                real_store_id
            ))

        print("📦 Inserting sales...")
        start = time.time()
        cursor.executemany(
            """INSERT INTO sales (
                transaction_id, day_of_week, price, quantity_sold, total_sale,
                customer_id, product_id, store_id
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            sales_values
        )
        conn.commit()
        print(f"✅ Inserted {len(sales_values)} sales in {round(time.time() - start, 2)}s. 🚫 Skipped {skipped}.")

        return {
            "status": "success",
            "message": f"Inserted {len(sales_values)} sales rows, skipped {skipped}."
        }

    except Exception as e:
        print("❌ Error:", str(e))
        return {
            "status": "error",
            "message": str(e)
        }

    finally:
        print("🔌 Closing connection...")
        cursor.close()
        conn.close()
