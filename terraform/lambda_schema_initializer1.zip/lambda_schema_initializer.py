import pymysql
import os

def handler(event, context):
    # Environment variables (set in Lambda console or Terraform)
    db_host = os.environ['RDS_HOST']
    db_user = os.environ['RDS_USER']
    db_password = os.environ['RDS_PASSWORD']
    db_name = os.environ['RDS_DB']

    # Connect to the database
    try:
        conn = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            connect_timeout=10
        )
    except Exception as e:
        print(f"ERROR: Could not connect to MySQL: {e}")
        return

    print("Connected to database")

    create_and_seed_db(conn)
    conn.close()
    print("Database schema initialized successfully.")

def create_and_seed_db(conn):
    with conn.cursor() as cur:
        # Products table
        cur.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id INT PRIMARY KEY,
            product_name VARCHAR(255),
            product_category VARCHAR(100)
        );
        """)
        cur.execute("DELETE FROM products;")  # Clear if rerun
        cur.executemany("""
        INSERT INTO products (product_id, product_name, product_category) VALUES (%s, %s, %s)
        """, [
            (1, 'iPhone 15', 'Smartphone'),
            (2, 'MacBook Pro', 'Laptop'),
            (3, 'Dell XPS 15', 'Laptop'),
            (4, 'Apple Watch Ultra', 'Smartwatch'),
            (5, 'Galaxy Watch 6', 'Smartwatch'),
            (6, 'Samsung Galaxy S23', 'Smartphone'),
        ])

        # Stores table
        cur.execute("""
        CREATE TABLE IF NOT EXISTS stores (
            store_id INT PRIMARY KEY,
            store_location VARCHAR(255)
        );
        """)
        cur.execute("DELETE FROM stores;")
        cur.executemany("""
        INSERT INTO stores (store_location, store_id) VALUES (%s, %s)
        """, [
            ('Pretoria', 1),
            ('Johannesburg', 2),
            ('Durban', 3),
        ])

        # Sales table (headers only)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            transaction_id INT PRIMARY KEY AUTO_INCREMENT,
            day_of_week VARCHAR(15),
            product_id INT,
            customer_id INT,
            store_id INT,
            price DECIMAL(10,2),
            quantity_sold INT,
            total_sale DECIMAL(10,2)
        );
        """)

        # Customers table (headers only)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id INT PRIMARY KEY,
            customer_name VARCHAR(255)
        );
        """)

        conn.commit()
        print("Tables created and seeded successfully.")
